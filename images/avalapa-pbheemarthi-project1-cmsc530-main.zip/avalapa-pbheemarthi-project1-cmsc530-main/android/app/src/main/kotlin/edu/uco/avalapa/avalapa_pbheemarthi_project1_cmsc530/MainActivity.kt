package edu.uco.avalapa.avalapa_pbheemarthi_project1_cmsc530

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
